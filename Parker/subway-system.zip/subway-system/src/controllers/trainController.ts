import { Request, Response } from 'express';
import { createTrainLine, getTrainLines, getTrainLineById, getStationsByLineId } from '../models/lineModel';

// Create a new train line
export const addTrainLine = async (req: Request, res: Response) => {
  const { name, fare, stations } = req.body;

  try {
    const result = await createTrainLine(name, fare, stations);
    res.status(201).json(result);
  } catch (error) {
    console.error('Error creating train line:', error);
    res.status(500).json({ error: 'Failed to create train line' });
  }
};

// Get all train lines
export const fetchAllTrainLines = async (req: Request, res: Response) => {
  try {
    const lines = await getTrainLines();
    res.status(200).json(lines);
  } catch (error) {
    console.error('Error fetching train lines:', error);
    res.status(500).json({ error: 'Failed to fetch train lines' });
  }
};

// Get a specific train line and its stations by ID
export const fetchTrainLineById = async (req: Request, res: Response) => {
  const lineId = parseInt(req.params.id, 10);

  try {
    const trainLine = await getTrainLineById(lineId);
    const stations = await getStationsByLineId(lineId);

    res.status(200).json({ trainLine, stations });
  } catch (error) {
    console.error('id=',lineId);
    console.error('Error fetching train line:', error);
    res.status(500).json({ error: 'Failed to fetch train line' });
  }
};
