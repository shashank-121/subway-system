import { Request, Response } from 'express';
import { pool } from '../database/database';

// Create or update a fare card
 
export const createFareCard = async (req: Request, res: Response) => {
  const { card_number, amount } = req.body;

  try {
    const cardResult = await pool.query(
      'INSERT INTO subway_system.fare_cards (card_number, balance) VALUES ($1, $2) ON CONFLICT (card_number) DO UPDATE SET balance = subway_system.fare_cards.balance + $2 RETURNING *',
      [card_number, amount]
    );

    res.status(201).json({
      message: 'Fare card created or updated successfully',
      card: cardResult.rows[0],
    });
  } catch (error) {
    console.error('Error creating or updating fare card:', error);
    res.status(500).json({ error: 'Failed to create or update fare card' });
  }
};


// Station entry with fare card
export const enterStation = async (req: Request, res: Response) => {
  const { card_number} = req.body;
  const { station_id } = req.params;

  if (!card_number || !station_id) {
    return res.status(400).json({ error: 'Card number and station ID are required' });
  }
  
  try {
    const cardResult = await pool.query('SELECT * FROM subway_system.fare_cards WHERE card_number = $1', [
      card_number,
    ]);

    if (cardResult.rowCount === 0) {
      return res.status(404).json({ error: 'Fare card not found' });
    }

    const card = cardResult.rows[0];

    if (card.balance < 2.75) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    const updatedCardResult = await pool.query(
      'UPDATE subway_system.fare_cards SET balance = balance - 2.75 WHERE card_number = $1 RETURNING *',
      [card_number]
    );

    await pool.query(
      'INSERT INTO subway_system.ride_logs (card_id, station_id, entry_exit) VALUES ($1, $2, $3)',
      [card.id, station_id, 'entry']
    );

    res.status(200).json({
      message: 'Entry successful',
      card: updatedCardResult.rows[0],
    });
  } catch (error) {
    console.error('Error processing station entry:', error);
    res.status(500).json({ error: 'Failed to process station entry' });
  }
};


// Station exit with fare card
export const exitStation = async (req: Request, res: Response) => {
  const { card_number } = req.body;
  const { station_id } = req.params;


  try {
    // Retrieve the fare card details
    const cardResult = await pool.query('SELECT * FROM subway_system.fare_cards WHERE card_number = $1', [
      card_number,
    ]);

    if (cardResult.rowCount === 0) {
      return res.status(404).json({ error: 'Fare card not found' });
    }

    const card = cardResult.rows[0];

    // Log the station exit
    await pool.query(
      'INSERT INTO subway_system.ride_logs (card_id, station_id, entry_exit) VALUES ($1, $2, $3)',
      [card.id, station_id, 'exit']
    );

    // Return the current balance (no additional fare deduction for exit)
    res.status(200).json({
      message: 'Exit successful',
      card,
    });
  } catch (error) {
    console.error('Error processing station exit:', error);
    res.status(500).json({ error: 'Failed to process station exit' });
  }
};

